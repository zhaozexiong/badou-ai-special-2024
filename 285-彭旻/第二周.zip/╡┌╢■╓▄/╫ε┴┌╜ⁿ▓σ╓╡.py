import cv2
import numpy as np

def function(img): # 定义一个函数，做图像的放大缩小功能处理
    height,width,channles = img.shape  # 读取图像的基础信息
    emptyImage = np.zeros((800,800,channles), np.uint8)
    # 新建一个800*800的放大空图像，是为了放放大后的原图，np.uint8一般都是这个
    sh = 800 / height  # h的算子
    sw = 800 / width   # w的算子
    for i in range(800):  # 遍历一下sh,sw
        for j in range(800):
            x = int(i/sh + 0.5)  # int是向下取整的，多加一点误差会小一点
            y = int(j/sw + 0.5)
            # x, y是原图的坐标信息
            emptyImage[i,j] = emptyImage[x,y] # 将原图的信息赋值给新的凸显中x,y信息
    return emptyImage


img = cv2.imread("lenna.png")
zoom = function(img)  # 将img图像放大处理
print(zoom)
print(img)
print(zoom.shape)
cv2.imshow("nearest_interp", zoom)
cv2.imshow("image", img)
cv2.waitKey(0)
