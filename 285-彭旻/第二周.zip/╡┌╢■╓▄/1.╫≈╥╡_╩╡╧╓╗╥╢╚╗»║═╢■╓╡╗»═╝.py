"""
import cv2   # 导入opencv库
import numpy as np  # 导入numpy库并改用别名
import matplotlib.pyplot as plt  # 用matplotlib库中pyplot来画图

# 灰度化图
img = cv2.imread('lenna.png')  # 通过opencv库的imread函数读取图像
h,w = img.shape[:2]   # 读取图像形状调用shape函数，灰度图只有两个信息高、宽
img_gray = np.zeros([h,w], img.dtype)
# 用numpy库的zeros函数新建一个零矩阵，后续灰度化的图像放在该矩阵中

for i in range(h):
    for j in range(w):   # 两层循环分别遍历高、宽
        m = img[i,j]  # 矩阵形式通过数据的方式传给m,是原图像不是转换后的灰度图
        img_gray[i,j] = int(m[0]*0.11 + m[1]*0.59 + m[2]*0.3)
        # 将opencv读取通道顺序BGR坐标转化给gray坐标并赋给新图像
# img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# img_gray = img
"""

# 灰度化
import cv2
import numpy as np

img = cv2.imread('lenna.png')   # 读取图片
h,w = img.shape[:2]     # 读取图片高、宽的信息
img_gray = np.zeros([h,w], img.dtype)    # 建立零矩阵放变化后的灰度图
for i in range(h):
    for j in range(w):
        m = img[i,j]   # 将原图片矩阵信息赋给m
        img_gray = int(m[0]*0.11 + m[1]*0.59 + m[2]*0.3)  # 灰度算法
print(img)
print(img_gray)
cv2.imshow("gray", img_gray)
cv2.waitKey()  # 想显示必须要加这句话


# 二值化
rows,cols = img_gray.shape
for i in range(rows):
    for j in range(cols):
        if img_gray[i,j] > 0.5:  # 0.5是中间值，若大于则为白色，反之为黑色
            img_gray[i,j] = 1
        else:
            img_gray[i,j] = 0
cv2.imshow('binary', img_gray)
cv2.waitKey()


